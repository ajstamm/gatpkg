## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- eval = FALSE, echo=FALSE------------------------------------------------
#  # This is a placeholder. We are not on CRAN yet.
#  You can install the released version of gatpkg from
#  [CRAN](https://CRAN.R-project.org) with `install.packages("gatpkg")`.

## ---- eval=FALSE--------------------------------------------------------------
#  install.packages("gatpkg")
#  library(gatpkg)
#  runGATprogram()

