## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----mergegeo, out.width = '50%', fig.cap = 'Merging by closest geographic centroid', echo = FALSE, fig.alt = 'Animation showing five areas merging by closest geographic centroid'----
knitr::include_graphics("images/merge_geo_animated.gif")

## ----mergepop, out.width = '50%', fig.cap = 'Merging by closest population-weighted centroid', echo = FALSE, fig.alt = 'Animation showing five areas merging by closest population-weighted centroid'----
knitr::include_graphics("images/merge_pop_animated.gif")

## ----mergeleast, out.width = '50%', fig.cap = 'Merging to neighbor with least value', echo = FALSE, fig.alt = 'Animation showing five areas merging to their neighbor with the least value'----
knitr::include_graphics("images/merge_least_animated.gif")

## ----mergesimilar, out.width = '50%', fig.cap = 'Merging to neighbor with most similar ratio', echo = FALSE, fig.alt = 'Animation showing five areas merging to their neighbor with the most similar ratio'----
knitr::include_graphics("images/merge_similar_animated.gif")

## ----nodespacing, out.width = '80%', fig.cap = 'Comparing detail as nodes are thinned', echo = FALSE, fig.alt = 'Example of three decreasing levels of detail as nodes are thinned'----
knitr::include_graphics("images/node_spacing.png")

## ----compactness, out.width = '80%', fig.cap = 'Compactness examples', echo = FALSE, fig.alt = 'Examples of two areas with high and low compactness, with overlaid circles'----
knitr::include_graphics("images/compactness_example.png")

