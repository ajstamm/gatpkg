## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----mergegeo, out.width = '50%', fig.cap = 'Animation of merging by closest geographic centroid', echo = FALSE----
knitr::include_graphics("images/merge_geo_animated.gif")

## ----mergepop, out.width = '50%', fig.cap = 'Animation of merging by closest population-weighted centroid', echo = FALSE----
knitr::include_graphics("images/merge_pop_animated.gif")

## ----mergeleast, out.width = '50%', fig.cap = 'Animation of merging to neighbor with the least value', echo = FALSE----
knitr::include_graphics("images/merge_least_animated.gif")

## ----mergesimilar, out.width = '50%', fig.cap = 'Animation of merging to neighbor with most similar ratio', echo = FALSE----
knitr::include_graphics("images/merge_similar_animated.gif")

## ----nodespacing, out.width = '80%', fig.cap = 'Example of decreasing level of detail as nodes are thinned', echo = FALSE----
knitr::include_graphics("images/node_spacing.png")



## ----compactness, out.width = '80%', fig.cap = 'Example of areas with high and low compactness, with overlaid circles', echo = FALSE----
knitr::include_graphics("images/compactness_example.png")

