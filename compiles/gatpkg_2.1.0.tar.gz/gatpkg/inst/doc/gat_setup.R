## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval=FALSE---------------------------------------------------------------
#  install.packages("devtools")
#  devtools::install_github("NYSTracking/gatpkg", dependencies = TRUE,
#                           build_vignettes = TRUE)

## ----eval=FALSE---------------------------------------------------------------
#  # from GitHub
#  install.packages("devtools")
#  devtools::install_github("NYSTracking/gatpkg", dependencies = TRUE,
#                           build_vignettes = TRUE)
#  # from CRAN (not yet available)
#  # install.packages("gatpkg")
#  library(gatpkg)
#  runGATprogram()

