## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----locatepath, eval = FALSE-------------------------------------------------
#  paste0(tools::getVignetteInfo("gatpkg", all = TRUE)[1, "Dir"], "/extdata/")

## ----rungat, eval = FALSE-----------------------------------------------------
#  gatpkg::runGATprogram()

## ----pbinitial, out.width = '60%', fig.cap = 'Initial Progress Bar', echo = FALSE----
knitr::include_graphics("images/pb_start.png")

## ----tpberror, echo=FALSE-----------------------------------------------------
warning('Error in structure(.External(.C_dotTclObjv, objv), class = "tclObj") : 
  [tcl] bad window path name ".113".')

## ----pbshp, out.width = '60%', fig.cap = 'Progress Bar: Identify Shapefile', echo = FALSE----
knitr::include_graphics("images/pb_loadshp.png")

## ----shpcode, echo = FALSE, eval = FALSE--------------------------------------
#  # code to generate window for locateGATshapefile.png
#  gatpkg::locateGATshapefile()

## ----shppic, fig.cap = 'Dialog: Identify Shapefile', echo = FALSE-------------
knitr::include_graphics("images/locateGATshapefile.png")

## ----pbid, out.width = '60%', fig.cap = 'Progress Bar: Identify Identifier', echo = FALSE----
knitr::include_graphics("images/pb_id.png")

## ----idcode, echo = FALSE, eval = FALSE---------------------------------------
#  # code to generate window for identifyGATid.png
#  gatpkg::identifyGATid(gatpkg::hftown@data)

## ----idpic, fig.cap = 'Dialog: Identify Identifier', echo = FALSE-------------
knitr::include_graphics("images/identifyGATid.png")

## ----pbboundary, out.width = '60%', fig.cap = 'Progress Bar: Identify Boundary', echo = FALSE----
knitr::include_graphics("images/pb_border.png")

## ----boundarycode, echo = FALSE, eval = FALSE---------------------------------
#  # code to generate window for identifyGATboundary.png
#  gatpkg::identifyGATboundary(data = gatpkg::hftown@data)

## ----boundarypic, fig.cap = 'Dialog: Identify Boundary', echo = FALSE---------
knitr::include_graphics("images/identifyGATboundary.png")

## ----pbaggregator, out.width = '60%', fig.cap = 'Progress Bar: Identify First Aggregator', echo = FALSE----
knitr::include_graphics("images/pb_aggs.png")

## ----agg1code, echo = FALSE, eval = FALSE-------------------------------------
#  # code to generate window for identifyGATaggregator1.png
#  gatpkg::identifyGATaggregators(gatpkg::hftown@data)

## ----agg1pic, fig.cap = 'Dialog: Identify First Aggregator', echo = FALSE-----
knitr::include_graphics("images/identifyGATaggregators.png")

## ----pb6, out.width = '60%', fig.cap = 'Progress Bar: Identify Exclusion Criteria', echo = FALSE----
knitr::include_graphics("images/pb_exclude.png")

## ----excludecode, echo = FALSE, eval = FALSE----------------------------------
#  # code to generate window for inputGATexclusions.png
#  gatpkg::inputGATexclusions(mapdata = gatpkg::hftown@data, step = 5)

## ----excludepic, fig.cap = 'Dialog: Identify Exclusion Criteria', out.width = '60%', echo = FALSE----
knitr::include_graphics("images/inputGATexclusions.png")

## ----excludepic2, fig.cap = 'Dialog: Confirm Exclusion Criteria', out.width = '40%', echo = FALSE----
knitr::include_graphics("images/confirmGATexclusions.png")

## ----pb7, out.width = '55%', fig.cap = 'Progress Bar: Identify Merge Type', echo = FALSE----
knitr::include_graphics("images/pb_pickmerge.png")

## ----mergecode, echo = FALSE, eval = FALSE------------------------------------
#  # code to generate window for inputGATmergepop.png
#  gatpkg::inputGATmerge(mapdata = gatpkg::hftown@data, aggvar = "TOTAL_POP", aggvar2 = "NONE", step = 6)

## ----mergepic, out.width = '50%', fig.cap = 'Dialog: Identify Merge Type', out.width = '60%', echo = FALSE----
knitr::include_graphics("images/inputGATmerge.png")
# fix this image and pre-select options

## ----pb8, out.width = '60%', fig.cap = 'Progress Bar: Identify Population Shapefile', echo = FALSE----
knitr::include_graphics("images/pb_loadpop.png")

## ----popcode, echo = FALSE, eval = FALSE--------------------------------------
#  # code to generate window for locateGATshapefile2.png
#  gatpkg::locateGATshapefile(type = "population", myfile = paste0(filepath, "hfblock"))

## ----popdialog, fig.cap = 'Dialog: Identify Population Shapefile', echo = FALSE----
knitr::include_graphics("images/locatepopulationfile.png")

## ----popconfirm, fig.cap = 'Dialog: Confirm Population Shapefile', echo = FALSE----
knitr::include_graphics("images/confirmGATpopvar.png")

## ----pb9, out.width = '60%', fig.cap = 'Progress Bar: Identify Rate Settings', echo = FALSE----
knitr::include_graphics("images/pb_rate.png")

## ----ratecode, echo = FALSE, eval = FALSE-------------------------------------
#  # code to generate window for inputGATrate.png
#  gatpkg::inputGATrate(mapdata = gatpkg::hftown@data,
#                       limitdenom = FALSE, step = 8)

## ----ratepic, out.width = '50%', fig.cap = 'Dialog: Identify Rate Settings', echo = FALSE----
knitr::include_graphics("images/inputGATrate.png")

## ----pb10, out.width = '60%', fig.cap = 'Progress Bar: Save KML', echo = FALSE----
knitr::include_graphics("images/pb_pickkml.png")

## ----kmlcode, echo = FALSE, eval = FALSE--------------------------------------
#  # code to generate window for saveGATkml.png
#  gatpkg::saveGATkml(step = 9)

## ----kmlpic, out.width = '45%', fig.cap = 'Dialog: Save KML', echo = FALSE----
knitr::include_graphics("images/saveGATkml.png")
# fix this image and pre-select options

## ----pb11, out.width = '60%', fig.cap = 'Progress Bar: Save File', echo = FALSE----
knitr::include_graphics("images/pb_picksave.png")

## ----savecode, echo = FALSE, eval = FALSE-------------------------------------
#  # code to generate window for saveGATfiles.png
#  gatpkg::saveGATfiles()

## ----savepic, fig.cap = 'Dialog: Save File', echo = FALSE---------------------
knitr::include_graphics("images/saveGATfiles.png")

## ----pb12, out.width = '60%', fig.cap = 'Progress Bar: Confirm GAT Settings', echo = FALSE----
knitr::include_graphics("images/pb_confirm.png")
# update screenshot with correct buttons

## ----confirmcode, echo = FALSE, eval = FALSE----------------------------------
#  # code to generate window for locateGATshapefile.png
#  gatvars <- list(aggregator1 = "TOTAL_POP", aggregator2 = "TOTAL_POP",
#                  myidvar = "ID", minvalue1 = 5000, minvalue2 = 5000,
#                  boundary = "COUNTY", rigidbound = TRUE, popvar = "Pop_tot",
#                  savekml = FALSE)
#  mergevars <- list(mergeopt1 = "closest", similar1 = "AREALAND",
#                    similar2 = "AREALAND", centroid = "population-weighted")
#  ratevars <- list(ratename = "pop_dens", numerator = "TOTAL_POP",
#                   denominator = "AREALAND", multiplier = 10000,
#                   colorname = "Greens")
#  exclist <- list(var1 = "B_TOT", var2 = "NONE", var3 = "NONE",
#                  math1 = "equals", math2 = "equals", math3 = "equals",
#                  val1 = 0, val2 = 0, val3 = 0, flagsum = 6)
#  filevars <- list(filein = "hftown", popfile = "hfpop",
#                   fileout = "hftown_agg5k15k_popwt",
#                   userin = "C:/users/ajs11/Documents/R/win-library/3.6/gatpkg/extdata/hftown",
#                   userout = "C:/Users/ajs11/Documents/hftown_agg5k15k_popwt")
#  
#  gatpkg::confirmGATbystep(gatvars = gatvars, ratevars = ratevars,
#                         mergevars = mergevars, exclist = exclist,
#                         filevars = filevars, savekml = FALSE, step = 11)

## ----confirmpic, out.width = '60%', fig.cap = 'Dialog: Confirm GAT Settings', echo = FALSE----
knitr::include_graphics("images/confirmGATdialog.png")

## ----pb13, out.width = '60%', fig.cap = 'Progress Bar: Read the Shapefile', echo = FALSE----
knitr::include_graphics("images/pb_readshp.png")

## ----pb14, out.width = '60%', fig.cap = 'Progress Bar: Run the Aggregation', echo = FALSE----
knitr::include_graphics("images/pb_doagg.png")

## ----pb15, out.width = '60%', fig.cap = 'Progress Bar: Clean Up the Shapefile', echo = FALSE----
knitr::include_graphics("images/pb_endagg.png")

## ----pb16, out.width = '60%', fig.cap = 'Progress Bar: Calculate GAT Compactness Ratio', echo = FALSE----
knitr::include_graphics("images/pb_cratio.png")

## ----pb17, out.width = '60%', fig.cap = 'Progress Bar: Map First Aggregation Variable', echo = FALSE----
knitr::include_graphics("images/pb_mapagg.png")

## ----mapa1, out.width = '45%', fig.show = "hold", fig.cap = 'Maps: First Aggregation Variable Before and After Aggregating', echo = FALSE----
knitr::include_graphics(c("images/map_before.png","images/map_after.png"))

## ----pb18, out.width = '60%', fig.cap = 'Progress Bar: Map Second Aggregation Variable', echo = FALSE, eval = FALSE----
#  knitr::include_graphics("images/pb18.png")

## ----pb19, out.width = '60%', fig.cap = 'Progress Bar: Compare Original and Aggregated Areas', echo = FALSE----
knitr::include_graphics("images/pb_mapdiff.png")

## ----mapca, fig.show = "hold", out.width = '90%', fig.cap = 'Map: Compare Original and Aggregated Areas', echo = FALSE----
knitr::include_graphics("images/map_compare.png")

## ----pb20, out.width = '60%', fig.cap = 'Progress Bar: Map GAT Compactness Ratio', echo = FALSE----
knitr::include_graphics("images/pb_mapcr.png")

## ----mapcr, fig.show = "hold", out.width = '90%', fig.cap = 'Map: Compactness Ratio', echo = FALSE----
knitr::include_graphics("images/map_cratio.png")

## ----pb21, out.width = '60%', fig.cap = 'Progress Bar: Map Your Desired Rate', echo = FALSE----
knitr::include_graphics("images/pb_maprate.png")

## ----mapr, fig.show = "hold", out.width = '90%', fig.cap = 'Map: Choropleth of Rate for Aggregated Areas', echo = FALSE----
knitr::include_graphics("images/map_rate.png")

## ----pbmaps, out.width = '60%', fig.cap = 'Progress Bar: Save a PDF of the maps', echo = FALSE----
knitr::include_graphics("images/pb_savemaps.png")

## ----rerun, eval = FALSE------------------------------------------------------
#  myfilepath <- "C:/users/ajs/mygatfilesettings.Rdata"
#  gatpkg::runGATprogram(settings = myfilepath)
#  

## ----pbold, out.width = '60%', fig.cap = 'Progress Bar: Save the Original Shapefile', echo = FALSE----
knitr::include_graphics("images/pb_saveold.png")

## ----pbnew, out.width = '60%', fig.cap = 'Progress Bar: Save the Aggregated Shapefile', echo = FALSE----
knitr::include_graphics("images/pb_savenew.png")

## ----pbkml, out.width = '60%', fig.cap = 'Progress Bar: Save the KML File', echo = FALSE----
knitr::include_graphics("images/pb_savekml.png")

## ----pblog, out.width = '60%', fig.cap = 'Progress Bar: Save the Log of Your Run', echo = FALSE----
knitr::include_graphics("images/pb_log.png")

## ---- eval = FALSE------------------------------------------------------------
#  The following files have been written to the folder
#  C:/Users/ajs11/Documents/GAT:
#    hftown_agg6k15k_popwt.dbf
#    hftown_agg6k15k_popwt.prj
#    hftown_agg6k15k_popwt.shp
#    hftown_agg6k15k_popwt.shx
#    hftown_agg6k15k_popwtin.dbf
#    hftown_agg6k15k_popwtin.prj
#    hftown_agg6k15k_popwtin.shp
#    hftown_agg6k15k_popwtin.shx
#    hftown_agg6k15k_popwtplots.pdf
#    hftown_agg6k15k_popwt.log
#    hftown_agg6k15k_popwtsettings.Rdata
#  
#  See the log file for more details.

