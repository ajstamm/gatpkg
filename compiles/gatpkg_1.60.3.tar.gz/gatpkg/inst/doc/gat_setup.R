## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- eval=FALSE--------------------------------------------------------------
#  # not run
#  install.packages("gatpkg")
#  library(gatpkg)
#  runGATprogram()

## -----------------------------------------------------------------------------
citation(package = "gatpkg")

