## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----pbinitial, fig.cap = 'Initial Progress Bar', echo = FALSE, fig.alt = 'Initial Progress Bar'----
knitr::include_graphics("images/pb_start.png")

## ----pbshp, fig.cap = 'Progress Bar: Identify Shapefile', fig.alt = 'Progress Bar: Identify Shapefile', echo = FALSE----
knitr::include_graphics("images/pb_loadshp.png")

## ----shppic, fig.cap = 'Dialog: Identify Shapefile', fig.alt = 'Dialog: Identify Shapefile', echo = FALSE----
# generate window for image
# gatpkg::locateGATshapefile()
knitr::include_graphics("images/pick_shp.png")

## ----pbid, fig.cap = 'Progress Bar: Identify Identifier', fig.alt = 'Progress Bar: Identify Identifier', echo = FALSE----
knitr::include_graphics("images/pb_id.png")

## ----idpic, fig.cap = 'Dialog: Identify Identifier', fig.alt = 'Dialog: Identify Identifier', echo = FALSE----
# generate window for image
# gatpkg::identifyGATid(gatpkg::hftown)
knitr::include_graphics("images/pick_id.png")

## ----pbboundary, fig.cap = 'Progress Bar: Identify Boundary', fig.alt = 'Progress Bar: Identify Boundary', echo = FALSE----
knitr::include_graphics("images/pb_border.png")

## ----boundarypic, fig.cap = 'Dialog: Identify Boundary', fig.alt = 'Dialog: Identify Boundary', echo = FALSE----
# generate window for image
# gatpkg::identifyGATboundary(shp = gatpkg::hftown)
knitr::include_graphics("images/pick_border.png")

## ----pbaggregator, fig.cap = 'Progress Bar: Identify Aggregators', fig.alt = 'Progress Bar: Identify Aggregators', echo = FALSE----
knitr::include_graphics("images/pb_aggs.png")

## ----aggpick, fig.cap = 'Dialog: Identify Aggregators', fig.alt = 'Dialog: Identify Aggregators', echo = FALSE----
# generate window for image
# gatpkg::identifyGATaggregators(gatpkg::hftown)
knitr::include_graphics("images/pick_aggregators.png")

## ----pb6, fig.cap = 'Progress Bar: Identify Exclusions', fig.alt = 'Progress Bar: Identify Exclusion Criteria', echo = FALSE----
knitr::include_graphics("images/pb_exclude.png")

## ----excludepic, fig.cap = 'Dialog: Identify Exclusions', fig.alt = 'Dialog: Identify Exclusion Criteria', echo = FALSE----
# generate window for image
# gatpkg::inputGATexclusions(shp = gatpkg::hftown, step = 5)
knitr::include_graphics("images/pick_exclude.png")

## ----excludepic2, fig.cap = 'Dialog: Confirm Exclusion Criteria', fig.alt = 'Dialog: Confirm Exclusion Criteria', echo = FALSE----
knitr::include_graphics("images/confirm_exclude.png")

## ----pb7, fig.cap = 'Progress Bar: Identify Merge Type', fig.alt = 'Progress Bar: Identify Merge Type', echo = FALSE----
knitr::include_graphics("images/pb_pickmerge.png")

## ----mergepic, fig.cap = 'Dialog: Identify Merge Type', fig.alt = 'Dialog: Identify Merge Type', echo = FALSE----
# generate window for image
# gatpkg::inputGATmerge(shp = gatpkg::hftown, aggvar = "TOTAL_POP", aggvar2 = "NONE", step = 6)
knitr::include_graphics("images/pick_merge.png")

## ----pb8, fig.cap = 'Progress Bar: Identify Population Shapefile', fig.alt = 'Progress Bar: Identify Population Shapefile', echo = FALSE----
knitr::include_graphics("images/pb_loadpop.png")

## ----popdialog, fig.cap = 'Dialog: Identify Population Shapefile', fig.alt = 'Dialog: Identify Population Shapefile', echo = FALSE----
# generate window for image
# gatpkg::locateGATshapefile(type = "population", myfile = paste0(filepath, "hfblock"))
knitr::include_graphics("images/pick_pop.png")

## ----popconfirm, fig.cap = 'Dialog: Confirm Population Shapefile', fig.alt = 'Dialog: Confirm Population Shapefile', echo = FALSE----
knitr::include_graphics("images/confirm_pop.png")
# Note to self: Add the "pick a variable" dialog to select the population variable.

## ----pb9, fig.cap = 'Progress Bar: Identify Rate Settings', fig.alt = 'Progress Bar: Identify Rate Settings', echo = FALSE----
knitr::include_graphics("images/pb_rate.png")

## ----ratepic, fig.cap = 'Dialog: Identify Rate Settings', fig.alt = 'Dialog: Identify Rate Settings', echo = FALSE----
# generate window for image
# gatpkg::inputGATrate(shp = gatpkg::hftown, limitdenom = FALSE, step = 8)
knitr::include_graphics("images/pick_rate.png")

## ----pb10, fig.cap = 'Progress Bar: Save KML', fig.alt = 'Progress Bar: Save KML', echo = FALSE----
knitr::include_graphics("images/pb_pickkml.png")

## ----kmlpic, fig.cap = 'Dialog: Save KML', fig.alt = 'Dialog: Save KML', echo = FALSE----
# generate window for image
# gatpkg::saveGATkml(step = 9)
knitr::include_graphics("images/pick_kml.png")

## ----pb11, fig.cap = 'Progress Bar: Save File', fig.alt = 'Progress Bar: Save File', echo = FALSE----
knitr::include_graphics("images/pb_picksave.png")

## ----savepic, fig.cap = 'Dialog: Save File', fig.alt = 'Dialog: Save File', echo = FALSE----
# generate window for image
# gatpkg::saveGATfiles()
knitr::include_graphics("images/pick_save.png")

## ----pb12, fig.cap = 'Progress Bar: Confirm GAT Settings', fig.alt = 'Progress Bar: Confirm GAT Settings', echo = FALSE----
knitr::include_graphics("images/pb_confirm.png")
# update screenshot with correct buttons

## ----confirmpic, fig.cap = 'Dialog: Confirm GAT Settings', fig.alt = 'Dialog: Confirm GAT Settings', echo = FALSE----
knitr::include_graphics("images/pick_confirm.png")

## ----pb13, fig.cap = 'Progress Bar: Read the Shapefile', echo = FALSE---------
knitr::include_graphics("images/pb_readshp.png")

## ----pb14, out.width = '60%', fig.cap = 'Progress Bar: Run the Aggregation', echo = FALSE----
knitr::include_graphics("images/pb_doagg.png")

## ----pb15, out.width = '60%', fig.cap = 'Progress Bar: Clean Up the Shapefile', echo = FALSE----
knitr::include_graphics("images/pb_endagg.png")

## ----pb16, out.width = '60%', fig.cap = 'Progress Bar: Calculate GAT Compactness Ratio', echo = FALSE----
knitr::include_graphics("images/pb_cratio.png")

## ----pb17, out.width = '60%', fig.cap = 'Progress Bar: Map First Aggregation Variable', echo = FALSE----
knitr::include_graphics("images/pb_mapagg.png")

## ----mapa1, out.width = '45%', fig.show = "hold", fig.cap = 'Maps: First Aggregation Variable Before and After Aggregating', echo = FALSE----
knitr::include_graphics(c("images/map_before.png","images/map_after.png"))

## ----pb18, out.width = '60%', fig.cap = 'Progress Bar: Map Second Aggregation Variable', echo = FALSE, eval = FALSE----
#  knitr::include_graphics("images/pb18.png")

## ----pb19, out.width = '60%', fig.cap = 'Progress Bar: Compare Original and Aggregated Areas', echo = FALSE----
knitr::include_graphics("images/pb_mapdiff.png")

## ----mapca, fig.show = "hold", out.width = '90%', fig.cap = 'Map: Compare Original and Aggregated Areas', echo = FALSE----
knitr::include_graphics("images/map_compare.png")

## ----pb20, out.width = '60%', fig.cap = 'Progress Bar: Map GAT Compactness Ratio', echo = FALSE----
knitr::include_graphics("images/pb_mapcr.png")

## ----mapcr, fig.show = "hold", out.width = '90%', fig.cap = 'Map: Compactness Ratio', echo = FALSE----
knitr::include_graphics("images/map_cratio.png")

## ----pb21, out.width = '60%', fig.cap = 'Progress Bar: Map Your Desired Rate', echo = FALSE----
knitr::include_graphics("images/pb_maprate.png")

## ----mapr, fig.show = "hold", out.width = '90%', fig.cap = 'Map: Choropleth of Rate for Aggregated Areas', echo = FALSE----
knitr::include_graphics("images/map_rate.png")

## ----pbmaps, out.width = '60%', fig.cap = 'Progress Bar: Save a PDF of the maps', echo = FALSE----
knitr::include_graphics("images/pb_savemaps.png")

## ----pbold, out.width = '60%', fig.cap = 'Progress Bar: Save the Original Shapefile', echo = FALSE----
knitr::include_graphics("images/pb_saveold.png")

## ----pbnew, out.width = '60%', fig.cap = 'Progress Bar: Save the Aggregated Shapefile', echo = FALSE----
knitr::include_graphics("images/pb_savenew.png")

## ----pbkml, out.width = '60%', fig.cap = 'Progress Bar: Save the KML File', echo = FALSE----
knitr::include_graphics("images/pb_savekml.png")

## ----pblog, out.width = '60%', fig.cap = 'Progress Bar: Save the Log of Your Run', echo = FALSE----
knitr::include_graphics("images/pb_log.png")

