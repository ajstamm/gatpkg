#	Geographic Aggregation Tool (GAT) version 1.34 Aug 28, 2015
#	
#
#	Environmental Health Surveillance Section
#	Bureau of Environmental and Occupational Epidemiology
#	New York State Department of Health
#     this program by Gwen Babcock October 9, 2009-November 6, 2013
#	for questions contact Gwen Babcock at gdb02@health.state.ny.us
#		or Thomas Talbot at tot01@health.state.ny.us
#purpose: to program Geographic Aggregation Tool (GAT) in R
#input: a shapefile map of areas
#	the map must contain a character variable which uniquely identifies areas and a numeric variable
# 	user input to select variables which uniquely identify areas, the aggregation variable
#		and optionally, variable of areas within which merging will be preferred (ex. county)
#	user input to give the amount the aggregation variable should be aggregated to
#		and preferred aggregation method - closest or least
#output: a shapefile, before and after cloropleth maps in R graphics
# 	for output regions, most numeric variables will be summed, except any named
#	x,y,GATx,GATy,latitude,longitude,lat,lon,long which will be averaged
#	character variables: the values of the last region merged in will be used
#	3 additional variables added: Sp_id for R row number
#	and GATx,GATy for geographic centroids as determined by this program 
#written in R-2.9.2 under Windows XP
#
#the following R packages are required:
# ,boot,class
#  package BARD no longer available #classInt,coda,deldir,e1071,gpclib,lattice,maptools,MASS,Matrix,nlme,RColorBrewer,rgdal,sp,spam,spdep,svDialogs,svMisc,tcltk
# suggested website to get R and packages: http://lib.stat.cmu.edu/R/CRAN/
#
#Jan 11, 2009 modified to add kml output
#want to add capability to use two variables, and to merge from the highest down instead of lowest up
# modify to use rgdal to read & write shapefile.  It allows for projection info, but does have other limitations

#Note: need to explicitly specify any libraries needed to run as a batch file,
#even those that would ordinarily be loaded by default

#have problem with svDialog list.  We hypothesize that it can bomb if the list contains less than 3 items
# so modify the program accordingly

#modify April 20, 2009 to put compactness ratio measure in output data

#beta v5 June 21, 2010 change dialogs to add 'back' and 'help' options
#beta v6 July 15, 2010 add option to calculate rate, added popup when aggregation occurs to warn of slowness
#			added column with number of areas per region
#			add comparison of file size with memory availability
#beta v6.1 December 7, 2010 add conditional code to run gpclibPermit() function if needed
#December 10, 2010 change name to production version 1.0
#Dec 14, 2010 add merging option to most similar neighbor
#May 2011 v 1.2 bug fixes: check for errors in rate calculations
#	and remove extra linking variable before re-exporting input shapfile
# October 27, 2011 found bug: will not export shapefile if field names are more than 10 characters
#		fix this by adding substring function to reduce variable name length if needed
#Sept 27,2012 modify to not standardize compactness ratios
#Feb 13, 2013 include version number and date in message, so it will be included in the log
#Aug 15, 2013 modify to work in R 3.0.1
#		That looks like it will take a lot of work
#		some packages I used before are no longer available, such as gpclib
#		svDialogs has changed - new function names
#	add progress dialog
#	also make KML output always, reprojecting if needed
#	need to wait for listboxes to be visible before populating them
#October 31, 2013 add code to make similarity based on a ratio, not a count
#November 5, 2013 change logic to merge in same specified boundary whenever possible, even if not #	contiguous
#November 7, 2013 test rates and similarity ratios for zero denominators.  Don't allow them
#	for similarity, but plot the rates while ignoring bad values
#November 8, 2013 change rate plot to show integers only, and use jenks(natural breaks)
#	because quintiles was not working
#Feb 5, 2014 fix bugs in transformations - wrong formula to calculate UTM zones; rename version to v1.31
#June 13, 2014 add filter to open dialog to limit view to shapefiles.
#April 10, 2015 fix problem: limit dialog messages to 255 characters
#August 28, 2015 fix typo mergoption->mergeoption
#November 20, 2015 fix typo indentified->identified

#packages:
#attached base packages:
#[1] tcltk     stats     graphics  grDevices utils     datasets  methods  
#[8] base     
#
#other attached packages:
# [1] Matrix_1.0-12      lattice_0.20-15    rgdal_0.8-10       foreign_0.8-53    
# [5] svDialogs_0.9-54   svGUI_0.9-54       classInt_0.1-20    e1071_1.6-1       
# [9] class_7.3-8        RColorBrewer_1.0-5 maptools_0.8-26    rgeos_0.2-19      
#[13] sp_1.0-11         

#loaded via a namespace (and not attached):
#[1] boot_1.3-9      coda_0.16-1     deldir_0.0-22   grid_3.0.1     
#[5] LearnBayes_2.12 MASS_7.3-26     nlme_3.1-109    spdep_0.5-62   
#[9] splines_3.0.1  


library(datasets)
library(utils)

setWindowTitle(":  NYSDOH Geographic Aggregation Tool (GAT)") #adds this as a suffix to the usual window title

setStatusBar("NYSDOH Geographic Aggregation Tool is running.  Please wait for dialogs.")
#appears that setStatusBar will not work in R3.0.1- maybe a bug


library(grDevices)
library(graphics)
library(stats)
library(methods)
#library(gpclib) #in case not automaticaly loaded
if(exists("gpclibPermit")==TRUE){gpclibPermit()} #might be disabled by default, this enables it
library(rgeos) #substitute for gpclib

#first, add libraries with relevant geographic ang gui functions functions
library(maptools)
library(RColorBrewer)
library(classInt)
library(classInt)
library(tcltk)
library(svDialogs)
tclRequire("BWidget") #need this to get a drop-down box?

#clean up from anything previously in R session
rm(list=ls(all=TRUE))

starttime<-Sys.time()

message<-"NYSDOH Geographic Aggregation Tool (GAT) v1.33 April 10, 2015"
message

########################################################################
#  Begin custom function for dialogs: gatgui
#   allows selection from a list, with scroll bar
#R tclTk code to create listbox with "back" next" "help" and "back" buttons
#list of function arguments:
#gattitle,gatlabel,gatlist,gathelpfile,gatdefaultselection
# function returns text: either "go back" or the selection from the list
# requires package tcltk
# returns "go back" or the selected item from the list, as text
#########################################################################

#this function from /pkg/svMisc/R/TempEnv.R, needed for gatgui and gatInput functions
TempEnv <-
function() {
    pos <-  match("TempEnv", search())
    if (is.na(pos)) { # Must create it
        TempEnv <- list()
        attach(TempEnv, pos = length(search()) - 1)
        rm(TempEnv)
        pos <- match("TempEnv", search())
    }
    return(pos.to.env(pos))
}

gatgui<-function(gattitle="GAT window",gatlabel="Please select one",gatlist=c("Choice1","Choice2","Choice3"),gathelpfile=paste("file://",getwd(),"/help/GAT vR1 manual.html",sep=""),gatdefaultselection=1)
{
tt<-tktoplevel()
tkwm.title(tt,gattitle)
scr <- tkscrollbar(tt, repeatinterval=5, command=function(...)tkyview(tl,...))
tl<-tklistbox(tt,height=5,selectmode="single",yscrollcommand=function(...)tkset(scr,...),background="white")
#height in above line controls height of listbox
fruits <- gatlist
for (i in (1:length(fruits)))
{
    tkinsert(tl,"end",fruits[i])
}

tkselection.set(tl,gatdefaultselection-1)  # Default fruit is Banana.  Indexing starts at zero.
#try changing gatdefaultselection-1 to gatdefaultselection to see if that works
OnOK <- function()
{
    listChoice <- fruits[as.numeric(tkcurselection(tl))+1]
    assign("res", listChoice, envir = TempEnv())
    tkdestroy(tl)
    tkdestroy(tt)
    return(listChoice)
}
OK.but <-tkbutton(tt,text="  Next> ",command=OnOK)
#use next for no final commitment, speific label like 'start' once committed
OnCancel <- function()
{
    quit(save="no")
}
Cancel.but <- tkbutton(tt,text=" Cancel ",command=OnCancel)
OnHelp <- function()
{
   browseURL(gathelpfile)
}
help.but <- tkbutton(tt,text="  Help  ",command=OnHelp)
OnBack <- function()
{
    listChoice<-"go back"
    assign("res", listChoice, envir = TempEnv())
    tkdestroy(tl)
    tkdestroy(tt)
    return(listChoice)
}
back.but <- tkbutton(tt,text=" <Back  ",command=OnBack)
#tkgrid(back.but,OK.but,column=0,row=10,sticky="w",pady=6,padx=20)
#tkgrid(OK.but,         column=0,row=10,sticky="e",pady=6,padx=20)
#tkgrid(Cancel.but,padx=1,pady=6,row=10,column=1)
#tkgrid(help.but,padx=1,pady=6,row=10,column=2)
tkgrid(tklabel(tt,text=gatlabel),columnspan=4) #need colspan to make sure scrollbar is next to list
tkgrid(tl,scr)
tkwait.visibility(tl)
tkgrid.configure(scr,rowspan=4,sticky="nsw")
tkgrid.configure(tl,sticky="e") #add this to try to improve appearance
tkgrid(back.but,OK.but,Cancel.but,help.but)
tkwait.visibility(help.but)

#microsoft suggests this order for buttons, with cancel and help to right?
tkfocus(tt)
tkwait.window(tt) #maybe need to wait? Need this for stuff to work
gatresult<-get("res", envir = TempEnv(), inherits = FALSE)
#remove res after outputting it
rm(list = "res",envir = TempEnv())
return(gatresult)
}

##################################################################
#  End custom dialog function
##################################################################

#################################################################
#Begin second custom dialog function: gatInput
# allows free typed input into a box
#R tclTk code to create listbox with "back" next" "help" and "back" buttons
#list of function arguments:
#gattitle,gatlabel,gathelpfile,gatdefaultselection
# function returns text: either "go back" or the selection from the list
# requires package tcltk
# returns "go back" or the input from the text box
#################################################################
gatInput<-function(gattitle="GAT input window",gathelpfile=paste("file://",getwd(),"/help/GAT vR1 manual.html",sep=""),
	gatdefault="default text",gatmessage="Please enter something in the box"){
#use this function for free text input, like the minimum values
assign("res.inbox",value=character(0),envir=TempEnv())
    inbox <- tktoplevel()
    tktitle(inbox) <- gattitle
    wlabel <- tklabel(inbox, text = gatmessage)
    varText <- tclVar(gatdefault)
    wtext <- tkentry(inbox, width = "50", textvariable = varText)
    onOk <- function() {
        assign(".res.inbox",value=tclvalue(varText),envir=TempEnv())
        tkdestroy(inbox)
        return(res.inbox)
    }
    onCancel<-function(){tkdestroy(inbox);quit(save="no")}
    OnBack<-function(){
    assign(".res.inbox", "go back", envir = TempEnv())
    tkdestroy(inbox)}
    OnHelp <- function(){browseURL(gathelpfile)}
    butFrame <- tkframe(inbox)
    wbutOK <- tkbutton(butFrame, text = "  Next>  ", width = "12", command = onOk, 
        default = "active")
    wlabSep <- tklabel(butFrame, text = " ")
    wbutCancel <- tkbutton(butFrame, text = "Cancel", width = "12", 
        command = onCancel)

help.but <- tkbutton(butFrame,text="  Help  ",width=12,command=OnHelp)
back.but <- tkbutton(butFrame,text=" <Back  ",width=12,command=OnBack)

    tkgrid(wlabel, sticky = "w", padx = 5, pady = 5)
    tkgrid(wtext, padx = 5, pady = 5)
    tkgrid(back.but,wbutOK, wlabSep, wbutCancel, help.but,sticky = "w") #add extra buttons
    tkgrid(butFrame, pady = 5)
    for (row in 0:2) tkgrid.rowconfigure(inbox, row, weight = 0)
    for (col in 0:0) tkgrid.columnconfigure(inbox, col, weight = 0)
    .Tcl("update idletasks")
    tkwm.resizable(inbox, 0, 0)
    tkbind(inbox, "<Return>", onOk)
    tkwm.deiconify(inbox)
    tkfocus(wtext)
    tkselection.from(wtext, "0")
    tkselection.to(wtext, as.character(nchar(gatdefault)))
    tkicursor(wtext, as.character(nchar(gatdefault)))
    tkwait.window(inbox)
    res<-get(".res.inbox", envir=TempEnv(), inherits=FALSE)
    remove(res.inbox,envir=TempEnv(),inherits=FALSE)
    return(res)
}#end gatInput function
############################################################################
# end gatInput function definition
#############################################################################

#################################################################
#Begin third custom dialog function: gatrateInput
# allows choice of two variables, the name of the rate, and the multiplier
#    has option not to calculate rate
#R tclTk code to create the dialog box with two listboxes, two free-text entry boxes,
#	and "back" "next" "cancel" and "help" buttons
#list of function arguments:
# gathelpfile,gatdefaultselection, gatlist1 and gatlist2
# function returns text vector with four items
# requires package tcltk
# returns [1] "go back" "no rate" or the rate name
#		[2] the multiplier
#		[3] numerator
#		[4] denominator
#file://P:/Sections/EHS/Aggregation/GAT/GAT vR4 manual.html
#################################################################
gatrateInput<-function(gathelpfile=paste("file://",getwd(),"/help/GAT vR1 manual.html",sep=""),
	gatdefaultselection=0,gatlist1=c("Apple","Orange","Banana","Pear","Cherry","Apricot","Peach"),
	gatlist2=c("Celery","Potato","Carrot","Tomato","Asparagus","Lettuce","Kale")){
#use this function for free text input, like the minimum values
# sequential palettes are: Blues BuGn BuPu GnBu Greens Greys Oranges OrRd PuBu PuBuGn PuRd Purples RdPu Reds YlGn YlGnBu YlOrBr YlOrRd 
colorlist<-c("Blues","Blue-Green","Blue-Purple","Green-Blue","Greens","Greys","Oranges","Orange-Red","Purple-Blue",
"Purple-Blue-Green","Purple-Red","Purples","Red-Purple","Reds","Yellow-Green","Yellow-Green-Blue","Yellow-Orange_Brown","Yellow-Orange-Red")
colors<-c("Blues","BuGn","BuPu","GnBu","Greens","Greys","Oranges","OrRd","PuBu","PuBuGn","PuRd","Purples","RdPu","Reds","YlGn","YlGnBu","YlOrBr","YlOrRd")
assign("res1.ratebox",value=character(0),envir=TempEnv())
assign("res2.ratebox",value=character(0),envir=TempEnv())
assign("resnum",value=gatlist1[gatdefaultselection],envir=TempEnv())
assign("resden",value=gatlist1[gatdefaultselection],envir=TempEnv())
assign("rescol",value=colorlist[gatdefaultselection],envir=TempEnv())
    ratebox <- tktoplevel()
    tktitle(ratebox) <- "NYSDOH GAT: calculate a rate" #window title
 #code for checkbox
	cb<-tkcheckbutton(ratebox)
  	checkboxlabel<-tklabel(ratebox,text="Do NOT calculate a rate")
  	cbValue<-tclVar("0")
	tkconfigure(cb,variable=cbValue)
	tkgrid(cb,column=1,sticky="e")
	tkgrid(checkboxlabel,column=2,row=0,sticky="w")
	#tkgrid.configure(cb,sticky="e")
 # end code for checkbox
#code for text entry box
    multlabel <- tklabel(ratebox, text = "Enter the rate multiplier\n ex. per 10,000 population")
    #multex<-tklabel(ratebox,text="ex. per 10,000 population")
    namelabel<-tklabel(ratebox,text="Enter the rate variable name\n ex. cancer_incidence")
    #nameex<-tklabel(ratebox,text="ex. cancer_incidence")
    perlabel<-tklabel(ratebox,text="per")
    varText1 <- tclVar("10,000")
    varText2 <-tclVar("gat_rate")
    multtext<- tkentry(ratebox, width = "20", textvariable = varText1)
    nametext<-tkentry(ratebox,width="20",textvariable=varText2)
#end code for text entry box

#add code for first listbox
scr <- tkscrollbar(ratebox, repeatinterval=5,
				   command=function(...)tkyview(tnum,...))
tnum<-tklistbox(ratebox,height=5,selectmode="single",exportselection=0,yscrollcommand=function(...)tkset(scr,...),background="white")
#selectmode can be single or extended
#height in above line controls height of listbox
firstlistlabel=tklabel(ratebox,text="Select the numerator")
secondlistlabel=tklabel(ratebox,text="Select the denominator")
thirdlistlabel=tklabel(ratebox,text="Select map color scheme")
#spacelabel=tklabel(ratebox,text="")
tkgrid(firstlistlabel,row=1,column=1)
tkgrid(secondlistlabel,row=1,column=3)
tkgrid(thirdlistlabel,row=1,column=5)
tkgrid.configure(firstlistlabel,sticky="e")
tkgrid.configure(secondlistlabel,sticky="e")
tkgrid.configure(thirdlistlabel,sticky="e")
fruits <- gatlist1
#tkwait.visibility(tnum)
for (i in (1:length(fruits)))
{
    tkinsert(tnum,"end",fruits[i])
}
tkselection.set(tnum,gatdefaultselection)  # Default fruit is Banana.  Indexing starts at zero.
#end first listbox code
#add code for second listbox
scrd <- tkscrollbar(ratebox, repeatinterval=5,
				   command=function(...)tkyview(tden,...))
tden<-tklistbox(ratebox,height=5,selectmode="single",exportselection=0,yscrollcommand=function(...)tkset(scrd,...),background="white")
#height in above line controls height of listbox
#tkgrid(tklabel(ratebox,text=gatlabel2))
#tkgrid(tnum,scr,tden,scrd)
tkgrid(tnum,row=2,column=1)
tkgrid(scr,row=2,column=2)
tkgrid(tden,row=2,column=3)
tkgrid(scrd,row=2,column=4)
tkgrid.configure(tnum,sticky="e")
tkgrid.configure(scr,rowspan=5,sticky="nsw") #rowspan=3
tkgrid.configure(tden,sticky="e")
tkgrid.configure(scrd,rowspan=5,sticky="nsw")#rowspan=4
veggies <- gatlist2
#tkwait.visibility(tden)
for (i in (1:length(veggies)))
{
    tkinsert(tden,"end",veggies[i])
}

#end second listbox code

#add code for third listbox (colors)
scrcol <- tkscrollbar(ratebox, repeatinterval=5,
				   command=function(...)tkyview(tcol,...))
tcol<-tklistbox(ratebox,height=5,selectmode="single",exportselection=0,yscrollcommand=function(...)tkset(scrcol,...),background="white")
#height in above line controls height of listbox
tkgrid(tcol,row=2,column=5)
tkgrid(scrcol,row=2,column=6)
tkgrid.configure(tcol,sticky="e")
tkgrid.configure(scrcol,rowspan=5,sticky="nsw")#rowspan=4
#tkwait.visibility(tcol)
for (i in (1:length(colorlist)))
{
    tkinsert(tcol,"end",colorlist[i])
}
tkselection.set(tden,gatdefaultselection)  # Default fruit is Banana.  Indexing starts at zero.
tkselection.set(tnum,gatdefaultselection)  # Default fruit is Banana.  Indexing starts at zero.
tkselection.set(tcol,0)

#end second listbox code


    onOk <- function() {
        assign("res1.ratebox",value=tclvalue(varText1),envir=TempEnv())
        assign("res2.ratebox",value=tclvalue(varText2),envir=TempEnv())
        listChoice1 <- fruits[as.numeric(tkcurselection(tnum))+1]
    listChoice2 <- veggies[as.numeric(tkcurselection(tden))+1]
    listChoice3 <- colors [as.numeric(tkcurselection(tcol))+1] #just get the number here
    assign("resnum", listChoice1, envir = TempEnv())
    assign("resden", listChoice2, envir = TempEnv())
    assign("rescol", listChoice3, envir = TempEnv())
    cbVal <- as.character(tclvalue(cbValue))
    if(cbVal=="1"){assign("res2.ratebox","no rate",envir=TempEnv())}
      tkdestroy(ratebox)
        #return(res.ratebox)
    }
    onCancel<-function(){tkdestroy(ratebox);quit(save="no")}
    OnBack<-function(){ratebox
    assign("res2.ratebox", "go back", envir = TempEnv())
    tkdestroy(ratebox)}
    OnHelp <- function(){browseURL(gathelpfile)}
    #butFrame <- tkframe(ratebox)
    wbutOK <- tkbutton(ratebox, text = "  Next>  ", width = "12", command = onOk, 
        default = "active")
    #wlabSep <- tklabel(butFrame, text = " ")
    wbutCancel <- tkbutton(ratebox, text = "Cancel", width = "12", 
        command = onCancel)

help.but <- tkbutton(ratebox,text="  Help  ",width=12,command=OnHelp)
back.but <- tkbutton(ratebox,text=" <Back  ",width=12,command=OnBack)
	
    tkgrid(namelabel, sticky="w", padx=5, column=1, row=8, rowspan=2,columnspan=2) #could also use pady=5
    #tkgrid(nameex,sticky="ne",padx=5,column=1,row=9)
    tkgrid(multlabel, sticky = "w", padx = 5,column=3, row=8, rowspan=2,columnspan=2)
    #tkgrid(multex,sticky="nw",padx=5,column=3,row=9)
    tkgrid(nametext,column=1,row=10,padx=5,sticky="w") #text entry box
    tkgrid(perlabel,column=2,row=10)
    tkgrid(multtext,column=3,row=10,padx = 5, pady = 5,columnspan=2,sticky="w") #text entry box
    tkgrid(back.but,column=1,row=11,pady=5)
     tkgrid(wbutOK,column=2,row=11,pady=5)
     tkgrid(wbutCancel,column=3,row=11,pady=5)
     tkgrid(help.but,column=4,row=11,pady=5)
    tkgrid.configure(back.but,sticky="e")
    tkgrid.configure(wbutOK,sticky="w")
    tkwm.resizable(ratebox, 0, 0)
    tkbind(ratebox, "<Return>", onOk)
    tkwm.deiconify(ratebox)
    tkfocus(multtext)
    tkselection.from(multtext, "0")
    tkwait.window(ratebox)
    res1<-get("res1.ratebox", envir=TempEnv(), inherits=FALSE)
    res2<-get("res2.ratebox",envir=TempEnv(), inherits=FALSE)
    res3<-get("resnum",envir=TempEnv(),inherits=FALSE)
    res4<-get("resden",envir=TempEnv(),inherits=FALSE)
    res5<-get("rescol",envir=TempEnv(),inherits=FALSE)
    remove(res1.ratebox,envir=TempEnv(),inherits=FALSE)
    remove(res2.ratebox,envir=TempEnv(),inherits=FALSE)
    remove(resnum,envir=TempEnv(),inherits=FALSE)
    remove(resden,envir=TempEnv(),inherits=FALSE)
    remove(rescol,envir=TempEnv(),inherits=FALSE)
rateuserin=c(res2,res1,res3,res4,res5)
return(rateuserin)
}#end gatrateInput function
#################################################################
# end third input function
################################################################


#######################################################################
#begin user input section
#######################################################################
step<-1 #default to start at step 1
#set up defaults for character variables chosen from list
myidvar<-"ID"
boundaryvar<-"county"
aggvar<-"count"
aggvar2<-"population"
mergeoption<-"closest"
ratestuff<-"no rate"

while(step<100){#get user input until finalized

if(step==1){fil<-matrix(nrow=1,ncol=2)
fil[,1]<-"Shapefiles"
fil[,2]="*.shp"
userfile<-choose.files(filters=fil,caption="Select Shapefile to aggregate")
userfile<-gsub("\\\\","/",userfile)
#userfile<-tclvalue(tkgetOpenFile( filetypes = "{{Shapefiles} {.shp}}",title="Select Shapefile to aggregate", initialdir=getwd())) #gives errors
#userfile<-dlgOpen(title = "Select Shapefile to aggregate", defaultFile = "towntest_region.shp", defaultDir = getwd(), multi=FALSE, filters=c("Shapefiles","*.shp"))$res
#this doesn't filer properly.  Instead, use tcltk

setStatusBar(paste("NYSDOH GAT: Looking for file ",userfile))
message<-paste("NYSDOH GAT: Looking for file ",userfile)
message
#remove extension if present
periodloc<-regexpr(".",userfile,fixed=TRUE) #will be -1 if no match, otherwise location(s) of matches
if(periodloc>0){userfile<-substr(userfile,1,periodloc[1]-1)}

checkfile=file.access(paste(userfile,".shp",sep=""),mode=4) #-1 for bad, 0 for OK

if(checkfile==0){#found shapefile}
#if found good shapefile
}else{#else needs to be on the same line as bracket so R knows the statement continues
print("Sorry, couldn't find shapefile")
dlgMessage("Sorry, couldn't find your shapefile", title = "File error",type="ok",icon="error")
quit(save="no")
}

#check the file size compared to memory limit
mysize<-10*file.info(paste(userfile,".shp",sep=""))[,"size"]/1048576+10*file.info(paste(userfile,".dbf",sep=""))[,"size"]/1048576
#/1048576 converts bytes to megabytes(Mb)
#not sure if shape part or dbf will be large - try combining both
mymem<-memory.limit(size=NA)
if(mysize>mymem){
x<-dlgMessage("Warning: your file may be too big for the GAT tool.  Do you wish to try it anyway?",
title="Possible file size problem",type="yesno",icon="warning")$res
if(x=="no"){quit(save="no")}
#I am not sure of the relationship between the size of the R objects produced by file import
#and the file size.  We are assumming 1:1 here, but this may not be correct.
#size appears to increase at least 10x going from disk to memory
}
#end section to check file size

setStatusBar(paste("NYSDOH GAT: Reading in data from ",userfile))

#read in map data only from the shapefile's dbf
library(foreign) #need in R 3.0
mapdata<-read.dbf(paste(userfile,".dbf",sep=""))
#once read in, get variable names and classes 


#repeat{ #allow the user to repeat these choices if they are not correct
listitems<-names(mapdata) #need to limit this to numeric variables
listitems
listtype<-sapply(mapdata,class) #get data classes for all columns
listtype[listtype=="factor"]<-FALSE
listtype[listtype=="character"]<-FALSE
listtype[listtype=="integer"]<-TRUE
listtype[listtype=="numeric"]<-TRUE
numlistitems<-listitems[listtype==TRUE]

if(length(numlistitems)<1){dlgMessage("Sorry, Your shape file has no numeric data and won't work in the GAT", title = "File data problem",type="ok",icon="error")
quit(save="no")}

setStatusBar("NYSDOH GAT:  Please respond to the dialogs")
message<-"NYSDOH GAT:  Please respond to the dialogs"
message
step<-2
} #end step 1

if(step==2){#ask user to select variable which uniquely identifies the areas to be merged

charlistitems<-listitems[listtype==FALSE]
noofchoices=length(charlistitems)
message<-"items for step 2"
message
charlistitems
noofchoices

if(noofchoices<1){dlgMessage("Sorry, Your shape file has no character data and won't work in the GAT", title = "File data problem",type="ok",icon="error")
quit(save="no")}

if(noofchoices==1){mycancel<-dlgMessage(paste("The variable which uniquely identifies the areas is ",charlistitems),title="Identification Variable", type="yesnocancel")$res
if(mycancel=="yes"){myidvar<-charlistitems}
if(mycancel=="no"){myidvar<-"go back";step<-1}
if(mycancel=="cancel"){quit(save="no")}
}

if(noofchoices>1){
#need to use previous myidvar as default if available
myindex<-grep(myidvar,charlistitems,value=FALSE)
if(length(myindex)<1){myindex<-1}
if(length(myindex) >1){myindex<-myindex[1]}
if(myindex<1){myindex<-1}

myidvar<-gatgui(gatlist=charlistitems,gatlabel="!Select a variable which uniquely identifies the areas:",gattitle="Itentification Variable",gatdefaultselection=myindex,gathelpfile=paste("file://",getwd(),"/help/GAT vR1 step2.html",sep="")) #cant seem to use anchors within a document, so try separate documents
}

#need to check that this variable does indeed uniquely identify each observation
if(myidvar!="go back"){checkdups<-mapdata[,myidvar]
charlistitems<-charlistitems[charlistitems!=myidvar]
noofchoices=length(charlistitems)
while(identical(unique(checkdups),checkdups)==FALSE & length(charlistitems)>0){#if not unique, ask for variable again

if(noofchoices==1){mycancel<-dlgMessage(paste("The variable which uniquely identifies the areas is ",charlistitems),title="Identification Variable", type="okcancel")$res
myidvar<-charlistitems}

if(noofchoices>1){
myidvar<-gatgui(gatlist=charlistitems,gatlabel="Select a variable which UNIQUELY identifies the areas:",gattitle="Itentification Variable",gathelpfile=paste("file://",getwd(),"/help/GAT vR1 step2.html",sep=""))}
#need to check that this variable does indeed uniquely identify each observation

 checkdups<-mapdata[,myidvar]
 charlistitems<-charlistitems[charlistitems!=myidvar]
 noofchoices=length(charlistitems)
} #end while loop to look for uniquely identifying variable

if(identical(unique(checkdups),checkdups)==FALSE){#if do not find unique identifying variable 
print("Sorry, there was no Identification variable, or it was numeric")
dlgMessage("Sorry, there was no Identification variable, or it was numeric.", title = "ID variable error",type="ok",icon="error")
quit(save="no")
}


rm(checkdups)
}#only check for duplicates if not going back

if(myidvar=="go back"){step<-1
}else{#go ahead
charlistitems<-listitems[listtype==FALSE]
charlistitems<-charlistitems[-which(charlistitems==myidvar)] #once we use a variable, remove it from the list
charlistitems<-append(charlistitems,"NONE",0) #add option of none for the boundaryvar

noofchoices=length(charlistitems) #should be at least two, because we add "NONE"
step<-3}
}#end step 2, asking for id variable

if(step==3){#ask user to select boundary variable, if present

if(noofchoices>1){
myindex<-grep(boundaryvar,charlistitems,value=FALSE)
if(length(myindex)<1){myindex<-1}
if(length(myindex)>1){myindex<-myindex[1]}
if(myindex<1){myindex<-1}

boundaryvar<-gatgui(gatlist=charlistitems,gatlabel="Variable which identifies boundaries within which merging is preferred:",gattitle="Boundary Variable",gatdefaultselection=myindex,gathelpfile=paste("file://",getwd(),"/help/GAT vR1 step3.html",sep=""))}else{boundaryvar<-"NONE"}

if(boundaryvar=="go back"){step<-2}else{step<-4}

}#end step 3, asking for boundary variable

if(step==4){
#ask for first aggregation variable
aggvar2<-"NONE" #set a default for second aggregation variable 
noofchoices=length(numlistitems)

if(noofchoices==1){mycancel<-dlgMessage(paste("The areas will be aggregated until the minimum value of ",numlistitems, "is reached"),title="First aggregation variable", type="yesnocancel")$res
if(mycancel=="yes"){aggvar<-numlistitems; step<-5}
if(mycancel=="no"){aggvar<-"go back";step<-3}
if(mycancel=="cancel"){quit(save="no")}
}

if(noofchoices>1){
myindex<-grep(aggvar,numlistitems,value=FALSE)
if(length(myindex)<1){myindex<-1}
if(length(myindex)>1){myindex<-myindex[1]}
if(myindex<1){myindex<-1}

aggvar<-gatgui(gatlist=numlistitems,gattitle="First Aggregation Variable",gatlabel="Aggregated until minimum value of this variable is reached:",gatdefaultselection=myindex,gathelpfile=paste("file://",getwd(),"/help/GAT vR1 step4.html",sep=""))}

if(aggvar=="go back"){step<-3}else{step<-5}

}#end step 4, first agg variable

if(step==5){#ask for the second aggregation variable, if needed

numlistitems2<-c("NONE",numlistitems[which(numlistitems!=aggvar)])

noofchoices=length(numlistitems2)

if(noofchoices>1){#aggvar2<-dlgList(numlistitems2, multi = FALSE, message = "Optionally, aggregate until minimum value of this variable is reached:", title = "Second aggregation variable", default = 1, nsel = NULL, new = FALSE, sort = FALSE, width = 50)$res

myindex<-grep(aggvar,numlistitems,value=FALSE)
if(length(myindex)<1){myindex<-1}
if(length(myindex)>1){myindex<-myindex[1]}
if(myindex<1){myindex=1}

aggvar2<-gatgui(gatlist=numlistitems2,gattitle="Second Aggregation Variable",gatlabel="Optionally, aggregate until minimum value of this variable is reached:",gatdefaultselection=myindex,gathelpfile=paste("file://",getwd(),"/help/GAT vR1 step5.html",sep=""))}else{aggvar2<-"NONE"}

if(aggvar2=="go back"){step<-4}else{step<-6}
minval=max(mapdata[,aggvar])

}#end step 5, 2nd agg var


if(step==6){#get first agg minimum value

minval<-gatInput(gatmessage=paste("Minimum value of",aggvar,"in output regions"), gattitle = "Minimum value", gatdefault = as.character(minval),gathelpfile=paste("file://",getwd(),"/help/GAT vR1 step6.html",sep=""))

while(is.na(as.numeric(minval))==TRUE&&minval!="go back"){
minval<-gatInput(gatmessage = paste("Please reenter the minimum value of",aggvar,"in output regions"), gattitle = "Minimum value", gatdefault = as.character(max(mapdata[,aggvar])),gathelpfile=paste("file://",getwd(),"/help/GAT vR1 step6.html",sep=""))
}#end while

if(minval=="go back"){step<-5}else{
if(aggvar2!="NONE"&&aggvar2!=aggvar){step<-7;minval2=max(mapdata[,aggvar2]);minval=as.numeric(minval)
}else{minval=as.numeric(minval);minval2<-minval;aggvar2<-aggvar;step<-8}}
}#end step 6

#step 7: may need to ask for second minimum value
if(step==7){
minval2<-gatInput(gatmessage = paste("Minimum value of",aggvar2,"in output regions"), gattitle = "Minimum value", gatdefault = as.character(minval2),gathelpfile=paste("file://",getwd(),"/help/GAT vR1 step7.html",sep=""))

while(is.na(as.numeric((minval2)))==TRUE&&minval2!="go back"){
#minval2<-dlgInput(message = paste("Please reenter the minimum value of",aggvar2,"in output regions"), title = "Minimum value", default = " ")
minval2<-gatInput(gatmessage = paste("Please reenter the minimum value of",aggvar2,"in output regions"), gattitle = "Minimum value", gatdefault = max(mapdata[,aggvar2]),gathelpfile=paste("file://",getwd(),"/help/GAT vR1 step7.html",sep=""))
}

if(minval2=="go back"){step<-6}else{step<-8;minval2<-as.numeric(minval2)}
}#end step 7

if(step==8){
#radiobutton dialog to get merge type
library(tcltk)
nextstep<-"not known"
tt <- tktoplevel()
tkwm.title(tt,"How to merge")
rbValue <- tclVar(0)
rb1 <- tkradiobutton(tt)
rb2 <- tkradiobutton(tt)
rb3 <- tkradiobutton(tt)
if(is.na(mergeoption)==FALSE){rbValue <- tclVar(mergeoption)} #try making this conditional
tkconfigure(rb1,variable=rbValue,value="closest")
tkconfigure(rb2,variable=rbValue,value="least")
tkconfigure(rb3,variable=rbValue,value="similar")
comboBox<-tkwidget(tt,"ComboBox",editable=FALSE,values=numlistitems)
comboBox2<-tkwidget(tt,"ComboBox",editable=FALSE,values=numlistitems)
tkconfigure(comboBox,values=numlistitems)
tkconfigure(comboBox2,values=numlistitems)
#tkselection.set(comboBox,0) #try setting default 
tkgrid(tklabel(tt,text="Merge with"))
tkgrid(rb1,tklabel(tt,text="closest area"),sticky="w")
if(aggvar!=aggvar2){
tkgrid(rb2,tklabel(tt,text=paste("area with least",aggvar,"and/or",aggvar2)),sticky="w")
}else{tkgrid(rb2,tklabel(tt,text=paste("area with least",aggvar)),sticky="w")}
tkgrid(rb3,tklabel(tt,text="area with most similar ratio of "),comboBox,tklabel(tt,text="to"),comboBox2,sticky="w")
#tkgrid(comboBox,sticky="e")
tkgrid.configure(rb1,rb2,rb3,sticky="e")

OnNext <- function()
{
    tempRbval<-as.character(tclvalue(rbValue))
    tempsimilarvar<-numlistitems[as.numeric(tclvalue(tcl(comboBox,"getvalue")))+1]
    tempsimilarvar2<-numlistitems[as.numeric(tclvalue(tcl(comboBox2,"getvalue")))+1]
    #msg<-paste("you selected ",tempsimilarvar)
    #tkmessageBox(title="var choice",message=msg)
    assign("Butval", "ahead", envir = TempEnv())
    assign("Simval",tempsimilarvar,envir= TempEnv())
    assign("Simval2",tempsimilarvar2,envir= TempEnv())
    assign("Rbval",tempRbval, envir=TempEnv())
    tkdestroy(tt)
    return(tempRbval)
}
next.but <- tkbutton(tt,text="  Next>  ",command=OnNext)
OnCancel <- function()
{
    quit(save="no")
}
Cancel.but <- tkbutton(tt,text=" Cancel ",command=OnCancel)
OnHelp <- function()
{
   browseURL(paste("file://",getwd(),"/help/GAT vR1 step8.html",sep=""))
}
help.but <- tkbutton(tt,text="  Help  ",command=OnHelp)
OnBack <- function()
{
    tempRbval<-as.character(tclvalue(rbValue))
    assign("Butval", "go back", envir = TempEnv())
    assign("Simval","none",envir= TempEnv())
    assign("Simval2","none",envir= TempEnv())
    assign("Rbval",tempRbval, envir=TempEnv())
    tkdestroy(tt)
    return(Butval)
}
back.but <- tkbutton(tt,text=" <Back  ",command=OnBack)

tkgrid(back.but,next.but,Cancel.but,help.but,pady=5) #sticky option?
tkwait.window(tt)
nextstep<-get("Butval", envir = TempEnv(), inherits = FALSE)
similarvar<-get("Simval",envir= TempEnv(), inherits = FALSE)
similarvar2<-get("Simval2",envir= TempEnv(), inherits = FALSE)
mergeoption<-get("Rbval",envir= TempEnv(), inherits = FALSE)

rm(list = "Butval",envir = TempEnv())
rm(list = "Simval",envir = TempEnv())
rm(list= "Rbval",envir=TempEnv())

if(nextstep=="go back"){
if(aggvar!=aggvar2){step<-7}else{step<-6}
}else{step<-9 #default is to go ahead
#do some quality control for similarity- force selection of different numerator and denominator variables and check for bad data
if(mergeoption=="similar"){
	if(similarvar==similarvar2){step<-8
	dlgMessage("Please select different variables for numerator and denominator",title="Please re-check",type="ok",icon="warning")}
#check if have problems like zero denominator.  If so, then require to pick again
check<-is.finite(mapdata[,similarvar]/mapdata[,similarvar2])
if((FALSE %in% check)&&step==9){step<-8
	dlgMessage("The variable selected for the denominator cannot have values of zero.  Please try again.",title="Please re-check",type="ok",icon="warning")}
}#end QC checks for similar merge option
}#end default go ahead
}#end of step 8: radiobutton dialog to get merge type

if(step==9&&length(numlistitems)>1){#get information for rate calculation
ratestuff<-gatrateInput(gatlist1=numlistitems,gatlist2=numlistitems,gathelpfile=paste("file://",getwd(),"/help/GAT vR1 step9.html",sep=""))

nummult<-gsub("[^0-9.]", "", ratestuff[2])  #get rid of all non-numeric characters
multiplier<-as.numeric(nummult)
if(is.na(multiplier)){multiplier<-1}
if(multiplier==0){multiplier<-1}

ratename<-gsub("([^a-z|A-Z|_])","",ratestuff[1]) #keep all altphabetical characters
if(ratename==""|is.na(ratename)){ratename<-"gat_rate"} #set a default if user gives invalid name
message<-paste("Rate variable is:",ratename,sep=" ")

if(ratestuff[1]=="go back"){step<-8}else{step<-10 #if we are not going back, we are going ahead
#do some quality control - force selection of different numerator and denominator variables
	if(ratestuff[3]==ratestuff[4]&&ratestuff[1]!="no rate"){step<-9
	dlgMessage("Please select different variables for numerator and denominator",title="Please re-check",type="ok",icon="warning")}
}#end else section

} #end of step 9: getting rate calcuation information

if(step==10){# add dialog to confirm merge settings

if(aggvar==aggvar2){#if have one aggregation variable

if(boundaryvar=="NONE"){#one aggregation variable, no boundary variable

if(mergeoption=="closest"){
mymessage<-paste("Input areas identified by ",myidvar," will be aggregated into regions containing at least ",minval," ",aggvar,".  Aggregegation to the closest adjacent area will be preferred.  Is this correct?",sep="")
}else if(mergeoption=="least"){#mergeoption is least
mymessage<-paste("Input areas identified by ",myidvar," will be aggregated into regions containing at least ",minval," ",aggvar,".  Aggregation to the the adjacent area with the fewest ",aggvar," will be preferred.  Is this correct?",sep="")
}else if(mergeoption=="similar"){
mymessage<-paste("Input areas identified by ",myidvar," will be aggregated into regions containing at least ",minval," ",aggvar,".  Aggregation to the the adjacent area with the closest value of ",similarvar,"/",similarvar2," will be preferred.  Is this correct?",sep="")
}

}else{#one aggregation variable, boundary variable

if(mergeoption=="closest"){
mymessage<-paste("Input areas identified by ",myidvar," will be aggregated into regions containing at least ",minval," ",aggvar,".  Aggregegation to the closest adjacent area within ",boundaryvar, " will be preferred.  Is this correct?",sep="")
}else if(mergeoption=="least"){#mergeoption is least
mymessage<-paste("Input areas identified by ",myidvar," will be aggregated into regions containing at least ",minval," ",aggvar,".  Aggregegation to the adjacent area with the fewest ",aggvar," within ",boundaryvar, " will be preferred.  Is this correct?",sep="")
}else if(mergeoption=="similar"){
mymessage<-paste("Input areas identified by ",myidvar," will be aggregated into regions containing at least ",minval," ",aggvar,".  Aggregegation to the adjacent area with the closest value of ",similarvar,"/",similarvar2," within ",boundaryvar, " will be preferred.  Is this correct?",sep="")
}

}#end if have one aggregation variable
}else{#if have two aggregation variables

if(boundaryvar=="NONE"){

if(mergeoption=="closest"){
mymessage<-paste("Input areas identified by ",myidvar," will be aggregated into regions containing at least ",minval," ",aggvar," and at least ",minval2, " ",aggvar2,".  Aggregegation to the closest adjacent area will be preferred.  Is this correct?",sep="")
}else if(mergeoption=="least"){#mergeoption is least
mymessage<-paste("Input areas identified by ",myidvar," will be aggregated into regions containing at least ",minval," ",aggvar," and at least ",minval2, " ",aggvar2,".  Aggregegation to the adjacent area with the least ", aggvar," or ",aggvar2," (as a percentage of the minimums requested) will be preferred.  Is this correct?",sep="")
}else if(mergeoption=="similar"){
mymessage<-paste("Input areas identified by ",myidvar," will be aggregated into regions containing at least ",minval," ",aggvar," and at least ",minval2, " ",aggvar2,".  Aggregegation to the adjacent area with the closest value of ", similarvar,"/",similarvar2," will be preferred.  Is this correct?",sep="")
}

}else{

if(mergeoption=="closest"){mymessage<-paste("Input areas identified by ",myidvar," will be aggregated into regions containing at least ",minval," ",aggvar," and at least ",minval2, " ",aggvar2,".  Aggregegation to the closest area within ",boundaryvar, "will be preferred.  Is this correct?",sep="")
}else if(mergeoption=="least"){
mymessage<-paste("Areas identified by ",myidvar," will be aggregated into regions containing at least ",minval," ",aggvar," and at least ",minval2, " ",aggvar2,".  Joining to the adjacent area within ",boundaryvar, "that has the least ", aggvar, " or ",aggvar2,"(as a % of the minimums) will be preferred.  Is this correct?",sep="")
}else if(mergeoption=="similar"){
mymessage<-paste("Input areas identified by ",myidvar," will be aggregated into regions containing at least ",minval," ",aggvar," and at least ",minval2, " ",aggvar2,".  Aggregegation to the adjacent area within ",boundaryvar, "that has the closest value of ", similarvar, "/", similarvar2, "  will be preferred.  Is this correct?",sep="")
}

}
}#end if have two aggregation variables


#find input file name and path
slashloc=max(unlist(gregexpr("/",userfile,fixed=TRUE))) #find location of last slash, divides path and file name
userfilein<-substr(userfile,slashloc+1,nchar(userfile))
userpathin<-substr(userfile,1,slashloc-1)

if(nchar(mymessage)>255){message<-"The confirmation dialog message is too long.  Some will not be shown."}
mymessage<-strtrim(mymessage,255)
mycancel<-dlgMessage(mymessage,title=paste("Confirm your choices for", userfilein,sep=""),type="yesnocancel",icon="question")$res
#might give error message if mymessage is too long? maybe need to limit to 255 char?

if(mycancel=="yes"){step<-100} #done with user input 
if(mycancel=="no"){step<-1} #if no, start again
if(mycancel=="cancel"){quit(save="no")}
}#end step 9, confirmation
} #end the while step<100
#}#end the repeat part, dont' need now that I'm using steps

#detach("package:svDialogs")
#detach("package:tcltk")
#quit() #use this statement for debugging so I don't have to go thru the whole program
#####################################
#end user input section
#####################################
#try also reading in using rgdal package?

setStatusBar(paste("NYSDOH GAT: Reading in map from ",userfile))

library(rgdal)
nytown.shp<-readOGR(dsn=userpathin,layer=userfilein) #reads it in as spatialpolygonsdataframe with projection information

nytown.shp <- spChFIDs(nytown.shp, as.character(nytown.shp@data[,myidvar]))

mycentroids<-coordinates(nytown.shp) #suggested to avoid get.Pcent.
colnames(mycentroids)<-c("GATx", "GATy")

#find if this map is lat/long or not
"input projection"
proj4string(nytown.shp)
myproj<-grepl("longlat",proj4string(nytown.shp),fixed=TRUE) #returns logical vector
#if projection is lat/lon, myproj=TRUE, otherwise FALSE
if(is.na(myproj)){myproj<-FALSE} #default to not lat/long if something goes wrong

setStatusBar(paste("NYSDOH GAT: Mapping ",userfile))

plot(nytown.shp)
title(paste(aggvar,"Before Merging")) #paste to aggvar
plotvar<-nytown.shp@data[,aggvar]
plotclr<-brewer.pal(5,"YlGn")
# sequential palettes are: Blues BuGn BuPu GnBu Greens Greys Oranges OrRd PuBu PuBuGn PuRd Purples RdPu Reds YlGn YlGnBu YlOrBr YlOrRd 
class<-classIntervals(plotvar,5,style="quantile")
# style can be "fixed", "sd", "equal", "pretty", "quantile", "kmeans", "hclust", "bclust", "fisher", or "jenks"
colcode<-findColours(class,plotclr)
plot(nytown.shp,col=colcode,add=TRUE)
legend("topleft",legend=names(attr(colcode,"table")),fill=attr(colcode,"palette"),cex=0.6, bty="n",inset=0)
#location can be "bottomright", "bottom", "bottomleft", "left", "topleft", "top", "topright", "right" and "center". 

#plot second aggregation variable
if(aggvar2!="NONE"&&aggvar2!=aggvar){
dev.new()
plot(nytown.shp)
title(paste(aggvar2,"Before Merging")) #paste to aggvar
plotvar2<-nytown.shp@data[,aggvar2]
plotclr2<-brewer.pal(5,"Purples")
# sequential palettes are: Blues BuGn BuPu GnBu Greens Greys Oranges OrRd PuBu PuBuGn PuRd Purples RdPu Reds YlGn YlGnBu YlOrBr YlOrRd 
class2<-classIntervals(plotvar2,5,style="quantile")
# style can be "fixed", "sd", "equal", "pretty", "quantile", "kmeans", "hclust", "bclust", "fisher", or "jenks"
colcode2<-findColours(class2,plotclr2)
plot(nytown.shp,col=colcode2,add=TRUE)
legend("topleft",legend=names(attr(colcode2,"table")),fill=attr(colcode2,"palette"),cex=0.6, bty="n",inset=0)
}
#end plot second aggregation variable before aggregation

setStatusBar(paste("NYSDOH GAT: Setting up aggregation of ",userfile))

#create a new map to work with
IDlist<-as.character(nytown.shp@data[,myidvar])

#newmap<-unionSpatialPolygons(nytown.shp,IDlist)
#the above is part of gpclib, try the below statement from rgeos instead
newmap<-gUnaryUnion(nytown.shp,IDlist)

library(spdep)

#get list of neighbors using poly2nb method from spdep packagetow
townnb<-poly2nb(nytown.shp, row.names=as.character(nytown.shp@data[,myidvar]), queen=FALSE)
oldtownnb<-townnb


detach("package:spdep") #after get neigbhors, this package might cause trouble

allpolydata<-nytown.shp@data
#add centroids to polygon data and rename the variables
allpolydata<-data.frame(allpolydata,mycentroids)
listtype<-sapply(allpolydata,class) #get data classes for all columns
listtype[listtype=="factor"]<-FALSE
listtype[listtype=="character"]<-FALSE
listtype[listtype=="integer"]<-TRUE
listtype[listtype=="numeric"]<-TRUE
listitems<-names(allpolydata) 


#convert factors to character
index<-sapply(allpolydata, is.factor)
allpolydata[,index]<-sapply(allpolydata[,index], as.character)
#convert integers to double 
index<-sapply(allpolydata,is.integer)
allpolydata[,index]<-sapply(allpolydata[,index],as.numeric)

minpop<-min(allpolydata[,aggvar])
minpop2<-min(allpolydata[,aggvar2]) #what happens when no 2nd aggregation variable?
newregno<-1

###############################################
#warn user that progress may be slow.  Replace this with pr
#library(tcltk)
#tt <- tktoplevel()

#tktitle(tt) <- "NYSDOH GAT: now merging areas"
# Create a button whose function (command) is to destroy the window
#OK.but <- tkbutton(tt,text="OK",command=function()tkdestroy(tt))
#slowtext<-tklabel(tt,text="Area aggregation is now occuring")
#slowtext2<-tklabel(tt,text="     this may be slow, please be patient     ")
#slowtext3<-tklabel(tt,text="") #spacer, to add margins
# Place the button on the window, using the grid manager.
#tkgrid(slowtext3)
#tkgrid(slowtext)
#tkgrid(slowtext2)
#tkgrid(slowtext3)
#tkgrid(OK.but) #ok button will fail if tcltk detached, so make user click the corner 'x' instead
#detach("package:tcltk")
#end slowness warning
############################################

#############################################
#start aggregation loop here
###########################################
pb <- winProgressBar(title="Area Aggregation Progress", label="Merging", min=0, max=100, initial=0)

while((minpop<minval)||(minpop2<minval2)) {

print(paste("merge number",newregno))
pblabel=paste("Merge number",newregno)
newmergeoption<-mergeoption #default merge option is the one selected
#pbno=50*(sin((newregno-1)/100)+1) #should give a number between 0 and 100
if(newregno/100==floor(newregno/100)|newregno==1){pbno=1}else{pbno=pbno+1}
setWinProgressBar(pb,pbno,label=pblabel)
setStatusBar(paste("NYSDOH GAT Merge number",newregno))

#add some code to change the merge order from high to low
tobemerged<-allpolydata[which((allpolydata[,aggvar]<minval)|(allpolydata[,aggvar2]<minval2)),]
#single line OR gives all results, double line gives only one row
lowpop<-order(tobemerged[,aggvar],decreasing=TRUE)
lowpop2<-order(tobemerged[,aggvar2],decreasing=TRUE)

#to sort both high to low, take the one whose highest value is the highest percentage of the minval
if(tobemerged[lowpop[1],aggvar]/minval>=tobemerged[lowpop2[1],aggvar2]/minval2){
first<-tobemerged[lowpop[1],]}else{
first<-tobemerged[lowpop2[1],]}

#previous code to merge from lowest up
#lowpop<-order(allpolydata[,aggvar]) #create vector, numbers indicate towns with lower pop
#first<-allpolydata[lowpop[1],] #get the first area to merges

townnbid<-attr(townnb,"region.id")
townnbidloc<-which(townnbid==first[,myidvar])

neighbors<-townnb[[townnbidloc]] #try a different way: result is neighbors as integer

neighborid<-townnbid[neighbors]

nbdata<-allpolydata[which(allpolydata[,myidvar] %in% neighborid),] #get the data about these neighbors

if(boundaryvar!="NONE"){
firstboundary<-as.character(first[,boundaryvar])
inco_dex=which(nbdata[,boundaryvar]==firstboundary) #index of neighbors in same county
inco_nbdata<-nbdata[inco_dex,] #can't use subset function with variable for variable name
#use observations in same county if possible, even if not adjacent
if(nrow(inco_nbdata)>0){nbdata<-inco_nbdata}else{
	print("No physically adjacent neighbors found in within same boundary")
	#edit here nov 5, 2013 to ensure mergining within county whenever possible.
	#get all in same county, first index then the data
	inco_alldex=which(allpolydata[,boundaryvar]==firstboundary&allpolydata[,myidvar]!=first[,myidvar])
	inco_alldata<-allpolydata[inco_alldex,]
	if(nrow(inco_alldata)>0){nbdata<-inco_alldata
	newmergeoption<-"closest"
 	print("Found not physically adjacent but in same boundary")}}
}#end if boundarvar is not NONE

#if no adjacent neighbors found, any area is a candidate for merging
if(nrow(nbdata)==0){print("No physically adjacent neighbors found")
	newmergeoption<-"closest" #don't want to use least or similar if no adjacent neighbors
	nbdata<-allpolydata[which(allpolydata[,myidvar]!=first[,myidvar]),]}

#distance for lat/long, in kilometers.  If longlat=false, euclidian distance in metric of points
mydist<-spDistsN1(as.matrix(nbdata[,c("GATx", "GATy")]),as.matrix(first[,c("GATx", "GATy")]),longlat=myproj)

nborder<-order(mydist) #order according to distance, this will be default

#order according to aggregation variable (i.e. cases or population) 
if(newmergeoption=="least"&&aggvar2=="NONE"){nborder<-order(nbdata[,aggvar1])}
if(newmergeoption=="least"&&aggvar2!="NONE"){
nborder1<-order(nbdata[,aggvar])
nborder2<-order(nbdata[,aggvar2])
if(nbdata[nborder1[1],aggvar]/minval<=nbdata[nborder2[1],aggvar2]/minval2){
nborder<-nborder1}else{nborder<-nborder2}} 
#end code for order according to aggregation variable

#order according to similarity
if(newmergeoption=="similar"){
#nborder<-order(nbdata[,similarvar]-first[,similarvar])
nborder<-order(abs(nbdata[,similarvar]/nbdata[,similarvar2]-first[,similarvar]/first[,similarvar2]))
}

newreg<-rbind(first,nbdata[nborder[1],]) #data which will be combined to form new region

nrid<-paste("GATid",as.character(newregno),sep="")

#a more generic way to create the newregdata

newlisttype<-as.logical(listtype)
newregchars<-newreg[2,!newlisttype] #take character variables from the 2nd region
#if only one character variable, must be ID but won't have name
if(length(newregchars)==1){newregchars<-data.frame(newregchars);names(newregchars)<-myidvar} #probably should be a more elegant way to take care of this case
#find possible lat/long/x/y variables
locvardex<-which(toupper(listitems)=="LATITUDE"|toupper(listitems)=="LONGITUDE"|toupper(listitems)=="X"|toupper(listitems)=="Y"|toupper(listitems)=="LAT"|toupper(listitems)=="LON"|toupper(listitems)=="LONG"|toupper(listitems)=="GATX"|toupper(listitems)=="GATY")
newregmeans<-sapply(newreg[,locvardex],mean)
newlisttype[locvardex]<-FALSE
newregnums<-(sapply(newreg[,newlisttype],sum)) #sum most numeric variables
#if only one numeric variable, wont get a data frame, so add a line to take care of that
if(length(names(newregnums))==0){newregnums<-data.frame(sum(newregnums));names(newregnums)<-aggvar} 

newregdata<-data.frame(c(newregchars,newregnums,newregmeans))
newregdata<-newregdata[,listitems] #make sure to keep same order of columns
newregdata[,myidvar]<-nrid #assign the new region the new id
row.names(newregdata)<-nrid #make sure the row name matches

allpolydata<-rbind(allpolydata,newregdata) #add the new region to the list of data about the regions
#need to remove the info about the old regions.  Maybe use != operator

allpolydata<-allpolydata[allpolydata[,myidvar]!=as.character(newreg[1,myidvar]),]
allpolydata<-allpolydata[allpolydata[,myidvar]!=as.character(newreg[2,myidvar]),]

minpop<-min(allpolydata[,aggvar]) #find the new minimum population
minpop2<-min(allpolydata[,aggvar2])

IDloc<-which(IDlist==newreg[1,myidvar]|IDlist==newreg[2,myidvar])
IDlist[IDloc]<-nrid

#can use aggregate.nb (of package spdep) to create new object listing neighbors of aggregate
library(spdep)

townnb<-aggregate.nb(oldtownnb,IDlist)

detach("package:spdep") #after get neigbhors, this package might cause trouble
newregno<-newregno+1
} 
close(pb)
##################################################################
#end of aggregation (loop)
##################################################################

setStatusBar(paste("NYSDOH GAT merging complete: ",newregno, " merges."))
tkdestroy(tt) #get rid of window if user hasn't clicked ok
#detach("package:tcltk")

#create and plot the new map
#can use unionSpatialPolygons(SpP,IDs,threshold=NULL) to join areas
newmap<-unionSpatialPolygons(nytown.shp,IDlist)

#get the number of polygons per region, and add
numpolys<-as.data.frame(table(IDlist)) #has IDlist + Freq
#data won't merge correctly with cbind()
allpolydata<-merge(allpolydata,numpolys,by.x=myidvar,by.y="IDlist")
#merge doesn't preserve row names like cbind - so add back the row names
row.names(allpolydata)<-allpolydata[,myidvar] #restore the row names
##but need to make sure the name is not more than 10 characters
names(allpolydata)[names(allpolydata)=="Freq"]<-paste("num_",substr(myidvar,1,5),"s",sep="")

###############################################################
#calculate the new rate here and map it, if needed
if(ratestuff[1]!="no rate"){#if should calculate rate
rate<-multiplier*allpolydata[ratestuff[3]]/allpolydata[ratestuff[4]]
names(rate)[names(rate)==ratestuff[3]]<-ratename
#takes the name of ratestuff[3], need to change this to ratename
allpolydata<-cbind(allpolydata,rate)
}#end if should calculate rate
#################################################################

newmapwdata<-SpatialPolygonsDataFrame(newmap, allpolydata, match.ID = TRUE) 

##################################################################
if(ratestuff[1]!="no rate"){#map the rate, chloropleth map
dev.new()
plot(newmap)
title(paste(ratename," per ",multiplier," After Merging"))
plotvarafter<-newmapwdata@data[,ratename]
#remove na's and infintes, from zero denominators
fpv=which(is.finite(plotvarafter))
plotvaraftergood<-plotvarafter[fpv]

breaksafter<-class$brks

rateplotclr<-brewer.pal(5,ratestuff[5])
# sequential palettes are: Blues BuGn BuPu GnBu Greens Greys Oranges OrRd PuBu PuBuGn PuRd Purples RdPu Reds YlGn YlGnBu YlOrBr YlOrRd 

classafter<-classIntervals(plotvaraftergood,5,style="jenks",cutlabels=TRUE,dataPrecision=0) #style can also be equal or quantile or fixed, with fixedbreaks=
#quantile does not work well with many zeros.  jenks is slow
#classafter<-classIntervals(plotvarafter,5,style="",fixedBreaks=breaksafter) 

colcodeafter<-findColours(classafter,rateplotclr) #assigns a color to each region
plot(newmap,col=colcodeafter,add=TRUE)
legend("topleft",legend=names(attr(colcodeafter,"table")),fill=attr(colcodeafter,"palette"),cex=0.6, bty="n",inset=0)
}#end mapping new rate
###############################################################


#find the new maximums after aggregation
maxpop<-max(allpolydata[,aggvar])
maxpop2<-max(allpolydata[,aggvar2])

dev.new()
plot(newmap)
title(paste(aggvar,"After Merging"))
plotvarafter<-newmapwdata@data[,aggvar]
breaksafter<-class$brks
#set upper limits for maps accordingly, so all data is within some range
breaksafter[6]<-maxpop
#classafter<-classIntervals(plotvarafter,5,style="quantile") #style can also be equal
classafter<-classIntervals(plotvarafter,5,style="fixed",fixedBreaks=breaksafter) #style can also be equal
colcodeafter<-findColours(classafter,plotclr) #assigns a color to each region
plot(newmap,col=colcodeafter,add=TRUE)
legend("topleft",legend=names(attr(colcodeafter,"table")),fill=attr(colcodeafter,"palette"),cex=0.6, bty="n",inset=0)

#plot second variable if needed
if(aggvar2!="NONE"&&aggvar2!=aggvar){
dev.new()
plot(newmap)
title(paste(aggvar2,"After Merging"))
plotvarafter2<-newmapwdata@data[,aggvar2]
breaksafter2<-class2$brks
#set upper limits for maps accordingly, so all data is within some range
breaksafter2[6]<-maxpop2
classafter2<-classIntervals(plotvarafter2,5,style="fixed",fixedBreaks=breaksafter2) #style can also be equal
colcodeafter2<-findColours(classafter2,plotclr2) #assigns a color to each region
plot(newmap,col=colcodeafter2,add=TRUE)
legend("topleft",legend=names(attr(colcodeafter2,"table")),fill=attr(colcodeafter2,"palette"),cex=0.6, bty="n",inset=0)
}



#try to plot new and old on same map
dev.new()
plot(nytown.shp, border="red",col="transparent",lty="solid",lwd=0.5)
par(new=TRUE)
plot(newmap,border="black",col="transparent",lty="solid",lwd=1.8)
#lty=line type (dotted) col=fill color, border=border color, lwd=line width
title("Map of original areas (red) and aggregations (black)")
#plot(layout.north.arrow(type=1)) #not sure how to use this
#also layout.scale.bar(height=0.05)
par(new=FALSE)


setStatusBar("NYSDOH GAT: please tell where to save the shapfile, log file and kml file")

library(svDialogs)
userfileout<-"" #set as default missing

while(userfileout==""){userout<-dlgSave(title = "Save New Map As", defaultFile = "", defaultDir = "",defaultExt = "", filters = c("Shapefiles (*.shp)", "*.shp"))$res
#now remove any file extention
periodloc=regexpr(".",userout,fixed=TRUE) #will be -1 if no match, otherwise location(s) of matches
if(periodloc>0){userout<-substr(userout,1,periodloc[1]-1)}

#find output file name and path
slashloc<-max(unlist(gregexpr("/",userout,fixed=TRUE))) #find location of last slash, divides path and file name
userfileout<-substr(userout,slashloc+1,nchar(userout))
userpathout<-substr(userout,1,slashloc-1)
#filename shouldn't contain ;=+<>|"[]/\'<>:*?

checkfile<-regexpr(";|:|\\+|=|<|>|\\||\\[|\\]|/|\"|'|\\*|\\?\n",userfileout,perl=TRUE)
if(checkfile[1]!="-1"){userfileout<-""}

checkfile<-charmatch("\\",userfileout,nomatch=-1)
if(checkfile[1]!="-1"){userfileout<-""}

if(userfileout==""){
dlgMessage("Your file name may have been invalid.  Please reenter your file name.",title="WARNING", type="ok")}
} #end while no good file name

#detach("package:svDialogs")

setStatusBar(paste("NYSDOH GAT: Writing shapfile to ",userout))

#write out shapefile using OGR
#writeOGR(newmapwdata, userpathout, userfileout, driver="ESRI Shapefile",verbose=TRUE, overwrite_layer=TRUE) #seems fast

#output also old map with ids of new regions
newoldid<-cbind(as.data.frame(IDlist),mapdata[myidvar]) 
row.names(newoldid)<-as.matrix(newoldid[myidvar])
names(newoldid)[1]<-"GATid" #change the name of the first part from IDlist

#all.equal(row.names(newoldid), row.names(as(nytown.shp, "data.frame"))
oldmapwdata<-spCbind(nytown.shp, newoldid[1]) #from maptools.  newoldid[2] is original variable-its a duplicate to add
writeOGR(oldmapwdata, userpathout, paste(userfileout,"in",sep=""), driver="ESRI Shapefile",verbose=TRUE, overwrite_layer=TRUE)
#writeOGR(newmapwdata, userpathout, userfileout, driver="ESRI Shapefile",verbose=TRUE, overwrite_layer=TRUE) #seems fast
#now also output kml. must be in lat/lon

#use BARD to evaluate the merging
#library(BARD)
#library(spdep) #BARD needs this but doesn't load it for some reason

setStatusBar("NYSDOH GAT: Analyzing merging: mapping compactness ratio")

#checkmapnew<-importBardShape(userout,id=myidvar,wantplan=FALSE)
#create a BARD plan from our data, which consists of assigning each area to itself
#for some reason, the following line needed to be changed to work with R 2.13.0he and BARD 1.10 as of June 1, 2010
#myaggplan<-createAssignedPlan(checkmapnew,predvar=myidvar)
#myaggplan<-createAssignedPlan(checkmapnew,predvar=1:length(newmapwdata))
#now use BARD evaluation functions: calculate compactness ratio
#need to choose a name less than 10 characters for writeOGR to work
#compact<-calcReockScore(myaggplan,lastscore=NULL,changelist=NULL,standardize=TRUE) #may return a vector or list
#compact_s<-calcReockScore(myaggplan,lastscore=NULL,changelist=NULL,standardize=FALSE) #may return a vector or list
#if standardize=true, then 0=best, 1=worst
#detach("package:BARD")

#newmap2<-spCbind(newmapwdata,compact_s)
#end using bard to evaluate merging
##############################################
#new code to look at compactness ratio
#need to get areas of newmapwdata
#is this already in the object, or do I need to use garea function?
#garea only works for planar coordinates
#ex:"+proj=utm +zone=18 +datum=NAD83 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0"
if(myproj==FALSE){planemap<-newmapwdata} 
#if not lat/lon, can use directly to calculate compactness ratio
if(myproj==TRUE){#if lat/long, need to reproject
#need to find approx longitude of map to pick an appropriate utm zone
#utms only for use between 80°S and 84°N latitude
#also there are exceptions for both UTM Zone Exceptions in Norway and Svalbard
mapcenter<-gCentroid(newmapwdata,byid=FALSE) #get center of map
latcenter<-mapcenter@coords[1]
#myutm<-floor((-75.5+180)/6)+1
myutm<-floor((latcenter+180)/6)+1
pstring<-paste("+proj=utm +zone=",myutm,"+datum=NAD83 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0",sep="")
planemap<-spTransform(newmapwdata,CRS(pstring))}
#start calculate compactness ratio
myareas<-gArea(planemap,byid=TRUE)
#another way to get an area?: test<-newmapwdata@polygons[[1]]@area
myhulls<-gConvexHull(planemap,byid=TRUE)
#myhulls@polygons[[1]]@Polygons[[1]]@coords to get coords from 1st object
hullcoords<-lapply(myhulls@polygons,function(y){y@Polygons[[1]]@coords})
hulldists<-lapply(hullcoords,dist)
diams<-sapply(hulldists,max)
#to get maximum distance (diameter of circle): max(dist(test1))
#crdata<-cbind(myareas,diams)
compactness.ratio<-function(a,d){
bca<-pi*((d/2)**2)
cr=a/bca
return(cr)
}
cratio<-compactness.ratio(myareas,diams)
newmap2wdata<-spCbind(newmapwdata,cratio)
#end calculate compactness ratio

#export the map as a shapefile
writeOGR(newmap2wdata, userpathout, userfileout, driver="ESRI Shapefile",verbose=TRUE, overwrite_layer=TRUE) #seems fast


#also reproject for KML
kmlmap<-spTransform(newmap2wdata,CRS("+proj=longlat +datum=NAD83 +no_defs +ellps=GRS80 +towgs84=0,0,0"))

#can only do kml if lat/lon
#might be able to reproject
#AZone <- spTransform(AmphZone27,CRS(proj4string(VegMap))) # reproject to CRS of VegMap
#"+proj=longlat +datum=NAD83 +no_defs +ellps=GRS80 +towgs84=0,0,0"
#if(myproj==TRUE){
kmlfilename<-paste(userpathout,paste(userfileout,"kml",sep="."),sep="/")

setStatusBar(paste("NYSDOH GAT: Writing KML file to ",kmlfilename))

mycolnames<-names(as(kmlmap,"data.frame"))

out<-sapply(slot(kmlmap,"polygons"),function(x){kmlPolygon(x,
name=as(kmlmap,"data.frame")[slot(x,"ID"),myidvar],
col=NULL,lwd=1.5,border='red',description=
paste("<table border=1>",
paste("<tr><td>",mycolnames,"</td><td>",
as(kmlmap,"data.frame")[slot(x,"ID"),mycolnames],"</td></tr>",collapse=" "),
"</table>")
)})

kmlfile<-file(kmlfilename,"w") #opens the file

#the next line describes the whole file
cat(kmlPolygon(kmlname=userfilein,kmldescription="<i>after aggregation</i>")$header,file=kmlfile, sep="\n")
cat(unlist(out["style",]),file=kmlfile,sep="\n")
cat(unlist(out["content",]),file=kmlfile, sep="\n")
cat(kmlPolygon()$footer,file=kmlfile,sep="\n")
close(kmlfile) 
#}
#this is the end of the code that creates the kml file

################################################################################
#create a log file
################################################################################
#begin log file
endtime<-Sys.time()
logfile<-paste(userpathout,paste(userfileout,"txt",sep="."),sep="/")

setStatusBar(paste("NYSDOH GAT: Writing log file ",logfile))

logtext<-"NYSDOH Geographic Aggregation Tool log"
write("",file=logfile,ncolumns=length(logtext),append=TRUE)

write(logtext,file=logfile,ncolumns=length(logtext),append=FALSE)
logtext<-c("The input file is: ",userfile)
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
logtext<-c("Input file field names are:  ",listitems)
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
logtext<-c("Number of input areas: ",nrow(mapdata))
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)

logtext<-c("The identification variable is: ",myidvar)
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
logtext<-c("The boundary variable is: ",boundaryvar)
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
write("",file=logfile,ncolumns=length(logtext),append=TRUE)

logtext<-c("The first aggregation variable is: ",aggvar)
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
logtext<-c("The minimum value of the first aggregation variable is: ",minval)
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
write("The pre-aggregation distribution of the first aggregation variable is:  ",file=logfile,ncolumns=length(logtext),append=TRUE)
logtext<-c(names(quantile(mapdata[,aggvar])))
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
logtext<-c(quantile(mapdata[,aggvar]))
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
write("",file=logfile,ncolumns=length(logtext),append=TRUE)

if(aggvar!=aggvar2){
logtext<-c("The second aggregation variable is: ",aggvar2)
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
logtext<-c("The minimum value of the second aggregation variable is: ",minval2)
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
write("The pre-aggregation distribution of the second aggregation variable is:  ",file=logfile,ncolumns=length(logtext),append=TRUE)
logtext<-c(names(quantile(mapdata[,aggvar2])))
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
logtext<-c(quantile(mapdata[,aggvar2]))
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
write("",file=logfile,ncolumns=length(logtext),append=TRUE)
}

logtext<-c("The merge type is: ",mergeoption)
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
logtext<-c("The projection is: ",proj4string(nytown.shp))
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
logtext<-c("The time this program took to run: ",endtime-starttime)
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)

logtext<-c("The output file is: ",userout)
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
logtext<-c("number of output regions: ",nrow(allpolydata))
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)

write("",file=logfile,ncolumns=length(logtext),append=TRUE)
write("The post-aggregation distribution of the first aggregation variable is:  ",file=logfile,ncolumns=length(logtext),append=TRUE)
logtext<-c(names(quantile(allpolydata[,aggvar])))
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
logtext<-c(quantile(allpolydata[,aggvar]))
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
write("",file=logfile,ncolumns=length(logtext),append=TRUE)

if(aggvar!=aggvar2){
write("The post-aggregation distribution of the second aggregation variable is:  ",file=logfile,ncolumns=length(logtext),append=TRUE)
logtext<-c(names(quantile(allpolydata[,aggvar2])))
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
logtext<-c(quantile(allpolydata[,aggvar2]))
write(logtext,file=logfile,ncolumns=length(logtext),append=TRUE)
write("",file=logfile,ncolumns=length(logtext),append=TRUE)
}

#end code to create log file
 
#create thematic map of compactness ratios
dev.new()
plot(newmap2wdata)
title(main="Compactness Ratio After Merging", sub="1=most compact, 0=least compact") #paste to aggvar
plotvar<-newmap2wdata@data[,"cratio"] #for some reason, newmap2@data[,compact_score] does't work
plotclr<-brewer.pal(5,"YlOrBr")
# sequential palettes are: Blues BuGn BuPu GnBu Greens Greys Oranges OrRd PuBu PuBuGn PuRd Purples RdPu Reds YlGn YlGnBu YlOrBr YlOrRd 
class<-classIntervals(plotvar,5,style="quantile")
# style can be "fixed", "sd", "equal", "pretty", "quantile", "kmeans", "hclust", "bclust", "fisher", or "jenks"
colcode<-findColours(class,plotclr)
plot(newmap2wdata,col=colcode,add=TRUE)
legend("topleft",legend=names(attr(colcode,"table")),fill=attr(colcode,"palette"),cex=0.6, bty="n",inset=0)


setStatusBar(paste("NYS GAT is finished.  Please also find your results in ",userpathout," Thank you."))
userpathout

#clean up
#rm(list=ls(all=TRUE))
